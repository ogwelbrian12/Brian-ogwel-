%% SPRING WEIGHT MINIMIZATION USING SIX MATLAB OPTIMIZERS
% Assignment: compare GA, fmincon, particleswarm, patternsearch,
% surrogateopt and simulannealbnd on the same spring-design problem.
%
% IMPORTANT:
% 1. The constraint expressions below are interpreted using g(x) >= 0.
% 2. The second constraint has x2-x1 in its denominator, so x2 must be
%    strictly greater than x1. A small separation is enforced.
% 3. GA, fmincon, patternsearch and surrogateopt accept nonlinear
%    constraints directly. particleswarm and simulannealbnd do not, so
%    they use a penalty function for the same constraints.

clc;
clear;
close all;

%% 1. DEFINE THE OPTIMIZATION PROBLEM
% Design variable vector:
% x(1) = wire diameter
% x(2) = mean coil diameter
% x(3) = number of active coils

objective = @(x) x(1)^2 * x(2) * (x(3) + 2);

% Lower and upper bounds from the assignment image.
lb = [0.05, 0.25, 2];
ub = [2.00, 1.30, 15];

% Prevent division by zero in the second constraint by requiring:
% x(2) - x(1) >= separation.
separation = 1e-4;

% Equivalent linear inequality: x(1)-x(2) <= -separation.
A = [1, -1, 0];
b = -separation;

% Nonlinear constraints in the form required by MATLAB solvers:
% MATLAB expects c(x) <= 0 and ceq(x) = 0.
% The picture's expressions are interpreted as g(x) >= 0,
% therefore c(x) = -g(x) <= 0.
nonlcon = @(x) springConstraints(x);

% A starting point inside the variable bounds and with x2 > x1.
x0 = [0.08, 0.40, 10];

%% 2. CHECK THE CONSTRAINT FORMULATION
[g0, ~] = springG(x0);
fprintf('Constraint values at the starting point [g1 g2 g3 g4]:\n');
disp(g0);

%% 3. PREPARE STORAGE FOR RESULTS
solverNames = {'ga'; 'fmincon'; 'particleswarm'; ...
               'patternsearch'; 'surrogateopt'; 'simulannealbnd'};

numberOfSolvers = numel(solverNames);
bestX = NaN(numberOfSolvers, 3);
bestWeight = NaN(numberOfSolvers, 1);
elapsedTime = NaN(numberOfSolvers, 1);
exitFlag = NaN(numberOfSolvers, 1);
status = strings(numberOfSolvers, 1);

% Fix the random seed to make stochastic runs more reproducible.
rng(10, 'twister');

%% 4. OPTIMIZER 1: GENETIC ALGORITHM (ga)
% GA is a population-based evolutionary optimization method.
try
    if exist('ga', 'file') == 2
        optionsGA = optimoptions('ga', ...
            'PopulationSize', 80, ...
            'MaxGenerations', 150, ...
            'Display', 'off');

        tic;
        [x, fval, flag] = ga(objective, 3, A, b, [], [], ...
            lb, ub, nonlcon, optionsGA);
        elapsedTime(1) = toc;

        bestX(1,:) = x;
        bestWeight(1) = fval;
        exitFlag(1) = flag;
        status(1) = "Completed";
    else
        status(1) = "Unavailable: Global Optimization Toolbox";
    end
catch ME
    status(1) = "Error: " + string(ME.message);
end

%% 5. OPTIMIZER 2: FMINCON
% fmincon is a gradient-based constrained optimization solver.
try
    if exist('fmincon', 'file') == 2
        optionsFmincon = optimoptions('fmincon', ...
            'Algorithm', 'sqp', ...
            'Display', 'off', ...
            'MaxFunctionEvaluations', 20000, ...
            'MaxIterations', 2000);

        tic;
        [x, fval, flag] = fmincon(objective, x0, A, b, [], [], ...
            lb, ub, nonlcon, optionsFmincon);
        elapsedTime(2) = toc;

        bestX(2,:) = x;
        bestWeight(2) = fval;
        exitFlag(2) = flag;
        status(2) = "Completed";
    else
        status(2) = "Unavailable: Optimization Toolbox";
    end
catch ME
    status(2) = "Error: " + string(ME.message);
end

%% 6. OPTIMIZER 3: PARTICLE SWARM (particleswarm)
% particleswarm handles bounds directly but not general nonlinear
% constraints. A penalty term is therefore added to the objective.
try
    if exist('particleswarm', 'file') == 2
        penaltyObjective = @(x) springPenaltyObjective(x, objective);

        optionsPS = optimoptions('particleswarm', ...
            'SwarmSize', 80, ...
            'MaxIterations', 250, ...
            'Display', 'off');

        tic;
        [x, penalizedValue, flag] = particleswarm( ...
            penaltyObjective, 3, lb, ub, optionsPS);
        elapsedTime(3) = toc;

        bestX(3,:) = x;
        bestWeight(3) = objective(x);  % Report actual weight, not penalty.
        exitFlag(3) = flag;
        status(3) = "Completed (penalty constraints)";
    else
        status(3) = "Unavailable: Global Optimization Toolbox";
    end
catch ME
    status(3) = "Error: " + string(ME.message);
end

%% 7. OPTIMIZER 4: PATTERN SEARCH (patternsearch)
% Pattern search is a derivative-free constrained optimization method.
try
    if exist('patternsearch', 'file') == 2
        optionsPattern = optimoptions('patternsearch', ...
            'Display', 'off', ...
            'MaxIterations', 1500, ...
            'MaxFunctionEvaluations', 30000);

        tic;
        [x, fval, flag] = patternsearch(objective, x0, A, b, ...
            [], [], lb, ub, nonlcon, optionsPattern);
        elapsedTime(4) = toc;

        bestX(4,:) = x;
        bestWeight(4) = fval;
        exitFlag(4) = flag;
        status(4) = "Completed";
    else
        status(4) = "Unavailable: Global Optimization Toolbox";
    end
catch ME
    status(4) = "Error: " + string(ME.message);
end

%% 8. OPTIMIZER 5: SURROGATE OPTIMIZATION (surrogateopt)
% Surrogate optimization builds an approximate model of the objective
% and searches it to reduce expensive objective evaluations.
try
    if exist('surrogateopt', 'file') == 2
        optionsSurrogate = optimoptions('surrogateopt', ...
            'Display', 'off', ...
            'MaxFunctionEvaluations', 1500);

        tic;
        [x, fval, flag] = surrogateopt(objective, lb, ub, ...
            nonlcon, optionsSurrogate);
        elapsedTime(5) = toc;

        bestX(5,:) = x;
        bestWeight(5) = fval;
        exitFlag(5) = flag;
        status(5) = "Completed";
    else
        status(5) = "Unavailable: Global Optimization Toolbox";
    end
catch ME
    status(5) = "Error: " + string(ME.message);
end

%% 9. OPTIMIZER 6: SIMULATED ANNEALING (simulannealbnd)
% Simulated annealing also accepts bounds but not general nonlinear
% constraints in simulannealbnd. Use the same penalty formulation
% used for particle swarm.
try
    if exist('simulannealbnd', 'file') == 2
        penaltyObjective = @(x) springPenaltyObjective(x, objective);

        optionsSA = saoptimset( ...
            'MaxIter', 3000, ...
            'Display', 'off');

        tic;
        [x, penalizedValue, flag] = simulannealbnd( ...
            penaltyObjective, x0, lb, ub, optionsSA);
        elapsedTime(6) = toc;

        bestX(6,:) = x;
        bestWeight(6) = objective(x);  % Actual spring weight.
        exitFlag(6) = flag;
        status(6) = "Completed (penalty constraints)";
    else
        status(6) = "Unavailable: Global Optimization Toolbox";
    end
catch ME
    status(6) = "Error: " + string(ME.message);
end

%% 10. CHECK FEASIBILITY AND DISPLAY RESULTS
% A result is feasible only if all g-values are >= 0 and x2 > x1.
feasible = false(numberOfSolvers, 1);
constraintValues = NaN(numberOfSolvers, 4);

for k = 1:numberOfSolvers
    if all(isfinite(bestX(k,:)))
        [g, ~] = springG(bestX(k,:));
        constraintValues(k,:) = g;
        feasible(k) = all(g >= -1e-6) && ...
                      (bestX(k,2) - bestX(k,1) >= separation - 1e-8);
    end
end

Results = table(solverNames, bestX(:,1), bestX(:,2), bestX(:,3), ...
    bestWeight, elapsedTime, exitFlag, feasible, status, ...
    'VariableNames', {'Optimizer','x1_WireDiameter','x2_CoilDiameter', ...
    'x3_ActiveCoils','SpringWeight','TimeSeconds','ExitFlag', ...
    'Feasible','Status'});

disp('OPTIMIZER COMPARISON RESULTS');
disp(Results);

% Save numerical results for the assignment report.
writetable(Results, 'Spring_Optimizer_Results.xlsx');
save('Spring_Optimizer_Results.mat', 'Results', ...
     'bestX', 'bestWeight', 'elapsedTime', 'constraintValues');

%% 11. GRAPH: COMPUTATION TIME FOR EACH OPTIMIZER
% Only plot optimizers that completed and returned a finite time.
validTimes = isfinite(elapsedTime);

figure;
bar(elapsedTime(validTimes));
set(gca, 'XTick', 1:sum(validTimes), ...
    'XTickLabel', solverNames(validTimes));
xtickangle(25);
ylabel('Execution time (seconds)');
xlabel('Optimization algorithm');
title('Computation Time Comparison of Spring Optimizers');
grid on;
saveas(gcf, 'Spring_Optimizer_Time_Comparison.png');

%% 12. OPTIONAL GRAPH: BEST SPRING WEIGHT
validWeights = isfinite(bestWeight);

figure;
bar(bestWeight(validWeights));
set(gca, 'XTick', 1:sum(validWeights), ...
    'XTickLabel', solverNames(validWeights));
xtickangle(25);
ylabel('Objective function value (spring weight index)');
xlabel('Optimization algorithm');
title('Best Objective Value Obtained by Each Optimizer');
grid on;
saveas(gcf, 'Spring_Optimizer_Weight_Comparison.png');

%% 13. PRINT A SIMPLE SUMMARY
fprintf('\nSUMMARY\n');
for k = 1:numberOfSolvers
    fprintf('%s: time = %.6f seconds, weight = %.8g, feasible = %d\n', ...
        solverNames{k}, elapsedTime(k), bestWeight(k), feasible(k));
end

%% LOCAL FUNCTION 1: CONSTRAINT EXPRESSIONS
function [g, ceq] = springG(x)
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);

    % Protect against the singular denominator x2-x1.
    if x1 <= 0 || x2 <= 0 || x3 <= 0 || abs(x2-x1) < 1e-12
        g = [-1e6; -1e6; -1e6; -1e6];
        ceq = [];
        return;
    end

    % Expressions transcribed from the supplied assignment image.
    g1 = (x2^3*x3)/(71785*x1^4) - 1;

    g2 = 1 - (4*x2^2 - x1*x2)/(12566*x1^3*(x2-x1)) ...
           - 1/(5108*x1^2);

    g3 = (140.45*x1)/(x2^2*x3) - 1;

    g4 = 1 - (x1+x2)/1.5;

    g = [g1; g2; g3; g4];
    ceq = [];
end

%% LOCAL FUNCTION 2: CONSTRAINTS FOR MATLAB SOLVERS
function [c, ceq] = springConstraints(x)
    [g, ceq] = springG(x);

    % MATLAB nonlinear solvers require c(x) <= 0.
    % The assignment expressions are interpreted as g(x) >= 0.
    c = [-g; x(1)-x(2)+1e-4];
end

%% LOCAL FUNCTION 3: PENALTY OBJECTIVE
function value = springPenaltyObjective(x, objective)
    [g, ~] = springG(x);

    % Penalize every violated nonlinear constraint.
    nonlinearViolation = max(0, -g);

    % Penalize violation of x2 > x1 + separation.
    separation = 1e-4;
    spacingViolation = max(0, x(1)-x(2)+separation);

    penaltyFactor = 1e6;
    value = objective(x) + penaltyFactor * ...
        (sum(nonlinearViolation.^2) + spacingViolation^2);
end
